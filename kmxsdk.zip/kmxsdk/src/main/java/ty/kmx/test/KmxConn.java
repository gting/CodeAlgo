package ty.kmx.test;

import tsinghua.thss.sdk.core.Client;
import tsinghua.thss.sdk.core.KMXClient;
import tsinghua.thss.sdk.core.KMXConfig;
import tsinghua.thss.sdk.read.Reader;
import tsinghua.thss.sdk.write.Writer;

import com.datastax.driver.core.ConsistencyLevel;

public class KmxConn {  
	public static Client getClient(){
		 

         KMXConfig config = KMXConfig.builder()
//        		 .setClusterNodes(new String[]{"192.168.15.114"})
//                 .setClusterNodes(new String[]{"192.168.30.162"})
//                 .setClusterNodes(new String[]{"192.168.30.176"})
                 .setClusterNodes(new String[]{"192.168.17.21"})
                 .setClusterPort(9042)
                 .setCoreConnectionsPerHost(3)
                 .setMaxConnectionsPerHost(10)
                 .setMaxRequestsPerConnection(4096)
                 .setHeartbeatIntervalSeconds(0)
                 .setTimeoutMillis(300000)
                 .setConsistencyLevel(ConsistencyLevel.ONE)
                 .setCacheSize(10000)
                 .setAutoBatch(false)
                 .build();
//                 .setAutoBatch(true)
//                 .setBatchSize(3000)
//                 .setLingerMs(2)
//                 .build();
         Client	client = new KMXClient(config);
         return client;
	}
}
