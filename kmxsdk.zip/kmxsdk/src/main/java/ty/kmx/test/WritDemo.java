package ty.kmx.test;

import static java.lang.System.exit;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;

import com.sagittarius.bean.common.TimePartition;
import com.sagittarius.bean.common.ValueType;
import com.sagittarius.exceptions.NoHostAvailableException;
import com.sagittarius.exceptions.QueryExecutionException;
import com.sagittarius.exceptions.TimeoutException;
import com.sagittarius.util.TimeUtil;
import com.sagittarius.write.SagittariusWriter.Data;

import tsinghua.thss.sdk.bean.common.Device;
import tsinghua.thss.sdk.bean.common.DeviceType;
import tsinghua.thss.sdk.bean.common.Sensor;
import tsinghua.thss.sdk.core.Client;
import tsinghua.thss.sdk.read.Reader;
import tsinghua.thss.sdk.write.Writer;

public class WritDemo {
	private static Writer writer;
	private static Reader reader;
	public static void main(String[] args) throws Exception {
		Client client=KmxConn.getClient();
		writer=client.getWriter();
		reader=client.getReader();
				
//		createDeviceType();
//		getDeviceType();
//		getAllDeviceType();
//		createDevice();
//		getDevice();
//		deleteDeviceType();
//		deleteSensorOfDeviceType();
		
//		getSensorsByDeviceId();
//		getAllDeviceByDeviceTypeId();
//		getAllDevice();
//		addSensors();
//		getValueType();
//		registerOwnerInfo();
//		getDeviceIdsByOwnerName();
//		insertData();
//		bulkInsertData();
//		addSensorsToDeviceType();
//		deleteSensorOfDevice();
//		deleteDevice();
//		deleteRange();
//		getNumberOfSensorsByDevices();
		exit(0);
	}
	private static void getSensorsByDeviceId() throws NoHostAvailableException, TimeoutException, QueryExecutionException {
		// TODO Auto-generated method stub

		List<Sensor> sensors =reader.getSensorsByDeviceId("10021425076");
		System.out.println(sensors);
		for(Sensor s:sensors){
			System.out.println("--------------------");
			System.out.println(s.getId());
			System.out.println(s.getDescription());
			System.out.println(s.getTimePartition());
			System.out.println(s.getValueType());
			System.out.println("--------------------");
		}
		System.out.println(sensors.size());
	}
	private static void createDeviceType() throws Exception {
		//增加一个设备类型
				DeviceType deviceType = new DeviceType();
//				deviceType.setId("TY_TYPE_LFL_IMEI");
				deviceType.setId("DS_DT");
//				deviceType.setDescription("LFL备用IMEI系列");
				List<Sensor> sensors = new ArrayList<>();
//				
//				sensors.add(new Sensor("TY_0001_Raw_ID", TimePartition.DAY, ValueType.STRING, "源码ID"));
//				sensors.add(new Sensor("TY_0001_Raw_Packet", TimePartition.DAY, ValueType.STRING, "源码数据JSON"));
		sensors.add(new Sensor("TC_0003_02_01", TimePartition.DAY, ValueType.FLOAT, "QC1"));
		sensors.add(new Sensor("TC_0003_02_02", TimePartition.DAY, ValueType.FLOAT, "QC2"));
		sensors.add(new Sensor("TC_0003_02_03", TimePartition.DAY, ValueType.FLOAT, "QC3"));
		sensors.add(new Sensor("TC_0003_02_04", TimePartition.DAY, ValueType.FLOAT, "QC4"));
				deviceType.setSensors(sensors);
				writer.createDeviceType(deviceType);
	}
	private static void getDeviceType() throws Exception {
		DeviceType typeA = reader.getDeviceType("DS_DT");//decode_type
		String deviceId = typeA.getId();
		List<Sensor> sensors = typeA.getSensors();
		System.out.println(deviceId+typeA.getDescription());
		for(Sensor s:sensors){
			System.out.println(s.getId()+"\t"+s.getValueType()+"\t"+s.getDescription());
		}
		System.out.println(sensors.size());
	}
	private static void getAllDeviceType() throws Exception {
		List<DeviceType> deviceTypes = reader.getAllDeviceType();
		for(DeviceType d:deviceTypes){

			System.out.println(d.getId()+"\t"+d.getDescription()+"\t"+d.getSensors());
		}
		
	}
	private static void createDevice() throws Exception {
		Device device1 = new Device();
		device1.setId("mq888888");
		
		device1.setDeviceTypeId("DS20170729171945267");
//
//		Device device2 = new Device();
//		device2.setId("139149");
//		device2.setDescription("139149号设备");
//		device2.setDeviceTypeId("MsgDaily");
//		
		writer.createDevice(device1);
//		device1.setId("fa2");
//		writer.createDevice(device1);
	}
	private static void getDevice() throws Exception {
		Device device = reader.getDeviceById("100210021");
		String desc = device.getDescription();
		System.out.println(device.getId()+"$$$$"+desc+"$$$$"+device.getDeviceTypeId());

	}
	private static void getAllDeviceByDeviceTypeId() throws Exception {
		List<Device> devices = reader.getDevicesByType("77BD885EB46E984B9FA64F758430ED44");//TML20171011142954438   DS20171101101804788
		int p=0;
		for(Device d:devices){
//			System.out.println("deviceIds.add(\""+d.getId()+"\");");
			System.out.println(d.getId());

			p++;
		}
		System.out.println(devices.size());
	}
	private static void getAllDevice() throws Exception {
		List<Device> devices = reader.getAllDevice();
		boolean flag=true;
//		for(Device d:devices){
//						System.out.println(d.getId()+"--------"+d.getDescription()+"--------"+d.getDeviceTypeId());
//
//		}
		for(Device d:devices){
//			System.out.println(d.getId()+"--------"+d.getDescription()+"--------"+d.getDeviceTypeId());
			/*if(d.getId().startsWith("1001")){
				flag=false;
				System.out.println(d.getId()+"--------"+d.getDescription()+"--------"+d.getDeviceTypeId());
			}*/
			if (d.getId().equals("1002111111"))
			{
				System.out.println(d.getId()+"--------"+d.getDescription()+"--------"+d.getDeviceTypeId());
			}
			Map<String,String> tagmap=d.getTags();
			if(tagmap!=null){
				for(String key:tagmap.keySet()){
					System.out.println(key+"-----------"+tagmap.get(key));
				}
			}

		}
		System.out.println(devices.size());
		System.out.println(flag);
	}
	//向设备添加新传感器
	private static void addSensors() throws Exception {
		List<Sensor> sensors = new ArrayList<>();
		sensors.add(new Sensor("TY_0000_MQ_TEST", TimePartition.DAY, ValueType.STRING, "MQ插入KMX测试工况"));
//		writer.addSensors("867330028541160", sensors);
//		writer.addSensors("867330028544404", sensors);
//		writer.addSensors("867330020651850", sensors);
//		writer.addSensors("864161025679247", sensors);
		writer.addSensors("mq888888", sensors);
	}
	//获得设备传感器的数据类型
	private static void getValueType() throws Exception {
		ValueType valueType = reader.getValueType("newsdk_d1","s3");
		System.out.println(valueType);
	}
	//为业主lfl注册设备
	private static void registerOwnerInfo() throws Exception {
		List<String> deviceIds = new ArrayList<>();
		deviceIds.add("newsdk_d1");
		
		writer.registerOwnerInfo("newsdk", deviceIds);
	}
	//查询业主lfl的所有设备
	private static void getDeviceIdsByOwnerName() throws Exception {
		List<String> deviceIds=reader.getDeviceIdByOwner("newsdk");
		System.out.println(deviceIds);
	}
	//单个插入数据
	private static void insertData() throws Exception {
		long time = TimeUtil.string2Date("2017-07-12 10:15:00");
		  String body = "{" + "\"sender\":\"6001100001\"" + "\"time\":12499550," + "\"duration\":60," + "\"mid\":\"6001100001\"," + "\"video\":\"http://12.34.3.3/dsfdsafafd\"," + "\"video_token\":\"jjjdkak3873kakdkf8e88353\"," + "\"data\":\"http://12.34.3.3/dsfdsafafd\"," + "\"data_token\":\"ffddgh3873kakdkf8e4345893\"" + "}";
		//
//		float val=117116706.000000F;
//		writer.insert("newsdk_d1", "s1", time, -1, TimePartition.DAY,val);
//		long l1=System.currentTimeMillis();
//		try {
			writer.insert("tybox_865473039599751", "GPS_LOCATION", System.currentTimeMillis(), 8888L,"test----------test");
//			writer.insert("0001144110", "MsgTPL_LFL_TEST2", 1502150888000L, -1,88);
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}finally{
//			System.out.println(System.currentTimeMillis()-l1);
//		}
		
		
//		writer.insert("newsdk_d1", "s2", time, -1, TimePartition.DAY,"我是测试S2");
//		writer.insert("newsdk_d1", "s3", time, -1, TimePartition.DAY,"我是doubleS3");

//	writer.closeSender();
	}
	//批量数据插入
	private static void bulkInsertData() throws Exception {
		Data data = writer.newData();
//		float val=1.222222F;
//		long time = TimeUtil.string2Date("2017-07-12 10:20:00");
//		long time2 = TimeUtil.string2Date("2017-07-12 10:30:00");
		int val=0;
		data.addDatum("1001128682", "TY_0002_00_15", 1516667234000L, 888888, val);
//		data.addDatum("newsdk_d1121", "s2", time, -1,TimePartition.DAY, "我是测试S2批量1");
//		data.addDatum("newsdk_d1222", "s3", time, -1,TimePartition.DAY, "我是测试S2批量2");
//		data.addDatum("newsdk_d1", "s3", time, -1,"我是doubleS3批量");
	
		writer.bulkInsert(data);
	}

	private static void addSensorsToDeviceType() throws Exception {
		//查询设备系列，获取设备系列描述
		DeviceType deviceType=reader.getDeviceType("TYPE-TEST-01");
		//要添加的传感器列表
		List<Sensor> sensors =new ArrayList<>();
		sensors.add(new Sensor("TY_0001_Raw_ID", TimePartition.DAY, ValueType.STRING, "源码ID"));
		sensors.add(new Sensor("TY_0001_Raw_Packet", TimePartition.DAY, ValueType.STRING, "源码数据JSON"));
		//查询设备系列下的所有设备列表
		List<Device> devices = reader.getDevicesByType("TYPE-TEST-01");
		//向设备系列添加传感器 第一个参数为要添加传感器的设备类型ID;第二个参数为要添加传感器的设备类型描述;第三个参数为设备类型的设备列表;第四个参数为要添加传感器列表
//		writer.addSensorsToDeviceType("TYPE-TEST-01", deviceType.getDescription(), devices, sensors);
	}


	private static void deleteDeviceType() throws NoHostAvailableException, QueryExecutionException, TimeoutException{
		int result = reader.deleteDeviceType("newsdk_type2");
		System.out.println(result);
	}
	private static void deleteSensorOfDeviceType() throws NoHostAvailableException, QueryExecutionException, TimeoutException{
		int result = reader.deleteSensorOfDeviceType("newsdk_type", "s2");
		System.out.println(result);
	}
	private static void deleteDevice() throws NoHostAvailableException, QueryExecutionException, TimeoutException{
		int result = reader.deleteDevice("800077001");
		System.out.println(result);
	}
	private static void deleteSensorOfDevice() throws NoHostAvailableException, QueryExecutionException, TimeoutException{
		int result = reader.deleteSensorOfDevice("newsdk_d2", "s2");
		System.out.println(result);
	}
	private static void deleteRange() throws NumberFormatException, ParseException, NoHostAvailableException, QueryExecutionException, TimeoutException{
		ArrayList<String> deviceIds = new ArrayList<>();
		 deviceIds.add("tybox_865473039599751");
        
		ArrayList<String> sensorIds = new ArrayList<>();
		sensorIds.add("GPS_LOCATION");
//        sensorIds.add("MsgTPL_LFL_TEST2");
//        sensorIds.add("MsgTPL_LFL_TEST3");
//        sensorIds.add("MsgTPL_zlbTest");
//        sensorIds.add("MsgTPL_zlbTest2");
		long startTime = TimeUtil.string2Date("2018-01-11 12:00:00.123");
		long endTime = TimeUtil.string2Date("2018-01-12 00:00:00.456");

		writer.deleteRange(deviceIds, sensorIds, startTime, endTime);
	}
	private static void getNumberOfSensorsByDevices() throws NumberFormatException, ParseException, NoHostAvailableException, QueryExecutionException, TimeoutException{
//		ArrayList<String> deviceIds = new ArrayList<>();
//		 deviceIds.add("1001134380");
//		 deviceIds.add("1001127502");
//		 deviceIds.add("1001141951");
//		 deviceIds.add("1001145605");
		
		//新接口
//		 List<Device> devices = reader.getDevicesByType("TML20171011142954438");
//		 ArrayList<String> deviceIds = new ArrayList<>();
//		 for(Device d:devices){
//			 deviceIds.add(d.getId());
//		 }
//		 System.out.println(deviceIds.size());
//		 long l1=System.currentTimeMillis();
//		 Map<String, Long> r4 = reader.getNumberOfSensors(deviceIds);		  
//		 System.out.println(r4);
//		 System.out.println(System.currentTimeMillis()-l1);
//		 
		 //旧方式
		 List<Device> devices = reader.getDevicesByType("TML20171011142954438");
		 Map<String, Long> map=new HashMap<String, Long>();
		 long l1=System.currentTimeMillis();
		 for(Device d:devices){
			 List<Sensor> list=reader.getSensorsByDeviceId(d.getId());
			 map.put(d.getId(), (long) list.size());
		 }			  
		 System.out.println(map);
		 System.out.println(System.currentTimeMillis()-l1);
	}
}
