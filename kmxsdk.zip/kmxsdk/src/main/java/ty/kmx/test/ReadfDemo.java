 package ty.kmx.test;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.sagittarius.bean.query.Shift;
import com.sagittarius.bean.result.StringPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sagittarius.util.TimeUtil;

import tsinghua.thss.sdk.bean.common.Device;
import tsinghua.thss.sdk.bean.common.Point;
import tsinghua.thss.sdk.read.Reader;
import tsinghua.thss.sdk.write.Writer;
import static java.lang.System.exit;
/**
 * 
 * @author lifaliang
 *
 */
public class ReadfDemo {
	 	private static Reader reader;
	    private static Writer writer;
	    private static final Logger logger = LoggerFactory.getLogger(ReadfDemo.class);
	    static SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		static java.text.DecimalFormat df2=new java.text.DecimalFormat("########.000000");
	    public static void main(String[] args) throws Exception{
	         reader = KmxConn.getClient().getReader();
	         writer=KmxConn.getClient().getWriter();
	         System.out.println(reader);
	         System.out.println(writer);
	        //住友设备DS20170816160549592
	         List<Device> devices = reader.getDevicesByType("DS20170609200719716");
	       //物流车设备
//	         List<Device> devices = reader.getDevicesByType("DS20170418222357430");
//	        //终端
//	         List<Device> devices = reader.getDevicesByType("TML20171011142954438");
	         
	         
	         ArrayList<String> deviceIds = new ArrayList<>();
	         for(Device d:devices){
	        	/* if(d.getId().startsWith("8000")){
	        		 deviceIds.add(d.getId());
	        	 }*/
	        	
	        	 System.out.println(d.getId());
	        	 if(deviceIds.size()>1000){
	        		 break;
	        	 }
	         }
//	         System.out.println(deviceIds);

//	         deviceIds.add("helmet_helmet1007");
//	         deviceIds.add("100210021");
//			deviceIds.add("762025558097");


	         ArrayList<String> sensorIds = new ArrayList<String>();
//
	         sensorIds.add("KM_0002_02_01");
//	         sensorIds.add("TC_0002_00_00");

	         long time1 = TimeUtil.string2Date("2018-05-07 00:00:00");
	         long time2 = TimeUtil.string2Date("2018-05-08 00:00:00");
//			long time1=1514944800632L;
//			long time2=1515676799000L;
//			long t=time1+(time2-time1)/2;
//			System.out.println(t);
//			StringPoint r5 = reader.getFuzzyStringPoint("helmet_helmet1007", "tybox", t,Shift.NEAREST);
//			Point r5 = reader.getFuzzyPoint("0001146520", "TY_0002_00_5", 1505135999000L,Shift.NEAREST);
//
//			System.out.println(r5);
//	         System.out.println(r5.getValue());
//	         System.out.println(r5.getPrimaryTime());
//	         System.out.println(r5.getSecondaryTime());


			//范围
	         range(deviceIds, sensorIds, time1, time2);
	         //最近
//	         last(deviceIds, sensorIds);
	         //点
//	         point(deviceIds, sensorIds, 1506918840489L);

	         exit(0);
		}
	   
	    
	    @SuppressWarnings("unchecked")
		public static void sortLongMethod(List list){
		    Collections.sort(list, new Comparator(){
				@Override
				public int compare(Object o1, Object o2) {
					Point p1=(Point)o1;
					Point p2=(Point)o2;
					if(p1.getPrimaryTime()<p2.getPrimaryTime()){
						return 1;
					}else if(p1.getPrimaryTime()==p2.getPrimaryTime()){
						return 0;
					}else{
						return -1;
					}
				}	    	
		    });		   
		}
	    
	    public static void last(ArrayList<String> deviceIds, ArrayList<String> sensorIds) throws Exception{
	    	 Map<String, Map<String, Point>> r6 = reader.getLatestPoint(deviceIds,sensorIds);
	         System.out.println(r6);
	         int num=0;

			for(String key:r6.keySet()){
					Map<String, Point> sensorData=r6.get(key);
					System.out.println(key);
					for(String key2:sensorData.keySet()){
						
						 System.out.println(df.format(new Date(sensorData.get(key2).getPrimaryTime()))+"\t"+key2+"\t" + sensorData.get(key2).getPrimaryTime() + "\t"+ sensorData.get(key2).getSecondaryTime()+ "\t" + sensorData.get(key2).getValue()+"*****"+sensorData.get(key2).getValueType());
	                     
	                     num=num+1;
					
					}
				}
	    }
	    public static void range(ArrayList<String> deviceIds, ArrayList<String> sensorIds,long time1,long time2) throws Exception{
	    	 Map<String, Map<String, List<Point>>> r7 = reader.getRange(deviceIds,sensorIds,time1,time2);
//			 System.out.println(r7);
			 int num=0;
			for(String key:r7.keySet()){
				Map<String, List<Point>> sensorData=r7.get(key);
//				System.out.println(key);
				for(String key2:sensorData.keySet()){
//					System.out.println(key2);
					List<Point> list=sensorData.get(key2);
					//时间倒序
//					sortLongMethod(list);
					System.out.println(list.size());
					for(Point p:list){
						 System.out.println("\t" + p.getPrimaryTime()+"\t"+df.format(new Date(p.getPrimaryTime())) + "\t"+ p.getSecondaryTime()+"\t"+ p.getValue()+"*****"+p.getValueType().name());
//						double f=Double.parseDouble(p.getValue());
//						System.out.println("shuzhi================"+f);
//						System.out.println(df2.format(f));
//						Map map2=JSON.parseObject(p.getValue());
//						System.out.println(map2.get("topic"));
//						long day=Long.parseLong(map2.get("timestamp")+"");
//
//						System.out.println(df.format(new Date(day)));
						num=num+1;
					}
				}
			}
			System.out.println(num);
			
//			long stimeDecode=r7.get("8000866104028879016").get("TY_0001_Decode_Packet").get(0).getSecondaryTime();
//        	long etimeDecode=r7.get("8000866104028879016").get("TY_0001_Decode_Packet").get(r7.get("8000866104028879016").get("TY_0001_Decode_Packet").size()-1).getSecondaryTime();
//        	System.out.println("s===="+stimeDecode);
//        	System.out.println("e===="+etimeDecode);
	    }
	    public static void point(ArrayList<String> deviceIds, ArrayList<String> sensorIds,long time1) throws Exception{
	    	 Map<String, Map<String, Point>> r4 = reader.getPrecisePoint(deviceIds, sensorIds, time1);
	        System.out.println(r4);       
	        for(String key:r4.keySet()){
		       	 Map<String, Point> map=r4.get(key);
		       	 for(String key2:map.keySet()){
		       		 System.out.println(key2+"========"+map.get(key2).getValue());
		       	 }
	        }
	    }
}
